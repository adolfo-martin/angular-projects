const fs = require('node:fs');

/**
 * 
 * @param { string } csvString 
 */
function csvToJson(csvString) {

    const lines = csvString.split('\n');

    const json = lines
        .filter((line, i) => i !== 0)
        .map(line => line.split(';'))
        .map(([
            numero,
            nombre_completo,
            apellidos,
            nombre,
            grupo,
            subgrupo,
            descripcion_subgrupo,
            fecha_nacimiento,
            expediente,
            nre,
            sexo,
            email,
            email_personal,
            telefono,
            telefono2,
            madre,
            padre,
            direccion,
            dni,
            nombre_foto,
            nivel,
            telefono_padre,
            telefono_madre,
            codigo_ensenanza,
            ensenanza,
            grupo_xz,
            tipo_padre,
            tipo_madre,
        ]) => {
            return {
                numero,
                nombre_completo,
                apellidos,
                nombre,
                grupo,
                subgrupo,
                descripcion_subgrupo,
                fecha_nacimiento,
                expediente,
                nre,
                sexo,
                email,
                email_personal,
                telefono,
                telefono2,
                madre,
                padre,
                direccion,
                dni,
                nombre_foto,
                nivel,
                telefono_padre,
                telefono_madre,
                codigo_ensenanza,
                ensenanza,
                grupo_xz,
                tipo_padre,
                tipo_madre,
            }
        });

    return json;
}

// Funcion para leer el archivo CSV y convertirlo a JSON utilizando la funcion anterior
function readCsvFileAndConvertToJson() {
    fs.readFile('2024-04-09_alumnos_DRIVE(2024-04-09).csv', 'utf8', (err, data) => {
        if (err) throw err;

        const json = csvToJson(data);

        guardarDatosAArchivo(json);
    });
}

async function guardarDatosAArchivo(inputData) {
    const content = JSON.stringify(inputData);
    fs.writeFile('./alumnos.json', content, err => {
      if (err) {
        console.error(err);
      } else {
        console.log('file written successfully');
      }
    });

}


readCsvFileAndConvertToJson();