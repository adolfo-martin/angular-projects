import Category from '../entities/Category';
import { v4 as generateUuid } from 'uuid';
import CanteenRepositoryInterface from './CanteenRepositoryInterface';

export default class CanteenRepositoryMock implements CanteenRepositoryInterface {
    static _categories: Category[] = CanteenRepositoryMock.setupCategories();


    static setupCategories(): Category[] {
        return [
            new Category(generateUuid(), 'Bebidas frías'),
            new Category(generateUuid(), 'Bebidas calientes'),
            new Category(generateUuid(), 'Bollería'),
            new Category(generateUuid(), 'Tapas'),
        ];
    }


    async retrieveCategories(): Promise<Category[]> {
        return CanteenRepositoryMock._categories;
    }
}