import User from '../entities/User';
import { v4 as generateUuid } from 'uuid';
import UsersRepositoryInterface from './UsersRepositoryInterface';

export default class UsersRepositoryMock implements UsersRepositoryInterface {
    
    static _users: User[] = UsersRepositoryMock._setupUsers();


    private static _setupUsers(): User[] {
        return [
            new User(generateUuid(), 'sonia.silverado', 'Sonia', 'Silverado', 's'),
            new User(generateUuid(), 'julio.juarez', 'Julio', 'Juarez', 'j'),
            new User(generateUuid(), 'luisa.laredo', 'Luisa', 'Laredo', 'l'),
            new User(generateUuid(), 'fernando.fonseca', 'Fernando', 'Fonseca', 'f'),
        ];
    }


    public async isValidUser(username: string, password: string): Promise<boolean> {
        return UsersRepositoryMock._users.some(
            user => user.username === username && user.password === password
        );
    }


    public async retrieveUserByUsernameAndPassword(username: string, password: string): Promise<User | undefined> {
        return UsersRepositoryMock._users.find(
            user => user.username === username && user.password === password
        );
    }
}