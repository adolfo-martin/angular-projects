import User from '../entities/User';

export default interface UsersRepositoryInterface {
    isValidUser(username: string, password: string): Promise<boolean>;
    retrieveUserByUsernameAndPassword(username: string, password: string): Promise<User | undefined>;
}