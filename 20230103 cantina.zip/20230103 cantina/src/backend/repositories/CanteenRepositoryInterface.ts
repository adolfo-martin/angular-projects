import Category from '../entities/Category';

export default interface CanteenRepositoryInterface {
    retrieveCategories(): Promise<Category[]>;
}