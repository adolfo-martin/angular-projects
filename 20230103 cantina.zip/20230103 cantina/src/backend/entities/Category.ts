export default class Category {
    constructor(private _uuid: string, private _name: string) {}

    get uuid(): string {
        return this._uuid;
    }

    get name() {
        return this._name;
    }
}