export default class User {
    constructor(
        private _uuid: string, 
        private _username: string, 
        private _firstname: string, 
        private _lastname: string,
        private _password: string,
    ) {}

    get uuid(): string {
        return this._uuid;
    }

    get username(): string {
        return this._username;
    }

    get firstname(): string {
        return this._firstname;
    }

    get lastname(): string {
        return this._lastname;
    }

    get password(): string {
        return this._password;
    }
}