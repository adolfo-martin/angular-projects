import CanteenRepositoryInterface from './repositories/CanteenRepositoryInterface';
import CanteenRepositoryMock from './repositories/CanteenRepositoryMock';
import UsersRepositoryInterface from './repositories/UsersRepositoryInterface';
import UsersRepositoryMock from './repositories/UsersRepositoryMock';
import AuthenticationServer from './servers/AuthenticationServer';
import CanteenServer from './servers/CanteenServer';

const canteenRepository: CanteenRepositoryInterface = new CanteenRepositoryMock();
// @ts-ignore
const canteenServer = new CanteenServer(process.env.CANTEEN_SERVER_PORT || 80, canteenRepository);
canteenServer.listen();

const usersRepository: UsersRepositoryInterface = new UsersRepositoryMock();
// @ts-ignore
const authenticationServer = new AuthenticationServer(process.env.AUTHENTICATION_SERVER_PORT || 81, usersRepository);
authenticationServer.listen();