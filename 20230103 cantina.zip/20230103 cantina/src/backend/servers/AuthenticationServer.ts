import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import UsersRepositoryInterface from '../repositories/UsersRepositoryInterface';
import User from '../entities/User';

export default class CanteenServer {
    private _app: express.Express
    private _refreshTokens: string[] = [];

    constructor(private _port: number, private _repository: UsersRepositoryInterface) {
        this._app = express();
        this._app.use(cors());
        this._app.use(express.json());
        this._app.use(express.urlencoded({ extended: true }));

        this._configureRoutes();
    }


    public listen() {
        this._app.listen(this._port, () => 
            console.log(`Authentication server listening on port ${this._port}`)
        );
    }

    
    private _configureRoutes(): void {
        this._app.post('/api/authenticate', this._validateUserAndPassword.bind(this));
    }


    private async _validateUserAndPassword(
        req: express.Request, 
        res: express.Response, 
        next: express.NextFunction): Promise<void> 
    {
        const username: string = req.body.username;
        const password: string = req.body.password;

        const isValidUser: boolean = await this._repository.isValidUser(username, password);
        if (!isValidUser) {
            setTimeout(() => {
                res.status(401).json({ 
                    ok: false, 
                    message: 'Cannot authenticate user. Username or password is wrong.'
                });
            }, 2000);
            return;
        }

        // @ts-ignore
        const user: User = await this._repository.retrieveUserByUsernameAndPassword(username, password);
        const { firstname, lastname } = user;
        const payload = { username, firstname, lastname };

        const accessToken = this._generateAccessToken(payload);
        const refreshToken = this._generateRefressToken(payload);
        this._refreshTokens.push(refreshToken);
        
        setTimeout(() => {
            res.status(200).json({ ok: true, accessToken, refreshToken});
        }, 2000);
    }


    // @ts-ignore
    private _generateAccessToken(user): string {
        return jwt.sign(
            user,
            // @ts-ignore
            process.env.ACCESS_TOKEN_SECRET || 'a91a848960fd61cb6240d06679c2ba14bbb753502cce7c62093aed36ff6d3fa7704f60e6f89b6159e156a8b758bad943d220ae9484221532f7fb440478ec580a',
            { expiresIn: `${60 * 60 * 4}s` },
        )
    }


    // @ts-ignore
    private _generateRefressToken(user): string {
        return jwt.sign(
            user,
            // @ts-ignore
            process.env.REFRESH_TOKEN_SECRET || '09ce0f8467b469068c198bc05a4cfc797fdc39d74103ddf559f5790655c882792864dcd4d8c1cbbcb78b4172d3ddd3e810733e41d4eed290f1e6fbf2df9c3698',
        )
    }


    // _validateToken(req: express.Request, res: express.Response) {
    //     const token = req.body.token;
    //     if (!token) {
    //         res.status(401)
    //             .json({ ok: false, message: 'There is no token.' });
    //         return;
    //     }

    //     // @ts-ignore
    //     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    //         if (err) {
    //             res.status(401)
    //                 .json({ ok: false, message: 'The access token is not valid.' });
    //             return;
    //         }

    //         res.status(200)
    //             .json({ ok: true, message: 'The token is valid' });
    //     })
    // }


    // _refreshToken(req: express.Request, res: express.Response) {
    //     const refreshToken = req.body.token;
    //     if (refreshToken === null) {
    //         res.status(401)
    //             .json({ ok: false, message: 'There is no refresh token.' });
    //         return;
    //     }

    //     if (!this._refreshTokens.includes(refreshToken)) {
    //         res.status(401)
    //             .json({ ok: false, message: 'The refresh token is not valid.' });
    //         return;
    //     }

    //     jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
    //         if (err) {
    //             res.status(401)
    //                 .json({ ok: false, message: 'The refresh token is not valid.' });
    //             return;
    //         }

    //         const accessToken = this._generateAccessToken(user);
    //         res.status(201)
    //             .json({ ok: true, accessToken });
    //     })
    // }


    // _deleteUser(req: express.Request, res: express.Response) {
    //     refreshToken = req.body.token;
    //     this._refreshTokens = this._refreshTokens
    //         .filter(token => token !== refreshToken);
    //     res.status(204)
    //         .json({ ok: true, message: 'The token was deleted.' });
    // }


    // private async _validateTokenMiddleware(
    //     req: express.Request, 
    //     res: express.Response, 
    //     next: express.NextFunction): Promise<void> 
    // {
    //     const token = getBearerToken(req);
    //     if (!token) {
    //         res.status(401)
    //             .json({ ok: false, message: 'There is no token.' });
    //         return;
    //     }
    
    //     jwt.verify(
    //         token, 
    //         process.env.ACCESS_TOKEN_SECRET || 'a91a848960fd61cb6240d06679c2ba14bbb753502cce7c62093aed36ff6d3fa7704f60e6f89b6159e156a8b758bad943d220ae9484221532f7fb440478ec580a',
    //         // @ts-ignore
    //         (err, user) => {
    //         if (err) {
    //             res.status(403)
    //                 .json({ ok: false, message: 'The access token is not valid.' });
    //             return;
    //         }
    
    //         // @ts-ignore
    //         req.user = user;
    //         next();
    //     })
    
    //         // @ts-ignore
    //     function getBearerToken(req) {
    //         const authHeader = req.headers['authorization'];
    //         const token = authHeader && authHeader.split(' ')[1];
    //         return token;
    //     }
    // }

}