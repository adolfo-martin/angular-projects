import CanteenRepositoryInterface from '../repositories/CanteenRepositoryInterface';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';

export default class CanteenServer {
    private _app: express.Express;

    constructor(private _port: number, private _repository: CanteenRepositoryInterface) {
        this._app = express();
        this._app.use(cors());

        this._configureRoutes();
    }


    public listen() {
        this._app.listen(this._port, () => 
            console.log(`Canteen server listening on port ${this._port}`)
        );
    }

    
    private _configureRoutes(): void {
        this._app.get('/api/categories', this._validateTokenMiddleware.bind(this), this._retrieveAndSendCategories.bind(this));
    }


    private async _retrieveAndSendCategories(req: express.Request, res: express.Response, next: express.NextFunction): Promise<void> {
        const categories = await this._repository.retrieveCategories();
        res.status(200)
            .json({ 
                ok: true, 
                categories: categories.map(({uuid, name}) => ({uuid, name}))
            });
    }

    private async _validateTokenMiddleware(
        req: express.Request, 
        res: express.Response, 
        next: express.NextFunction): Promise<void> 
    {
        const token = getBearerToken(req);
        if (!token) {
            res.status(401)
                .json({ ok: false, message: 'There is no token.' });
            return;
        }
    
        jwt.verify(
            token, 
            process.env.ACCESS_TOKEN_SECRET || 'a91a848960fd61cb6240d06679c2ba14bbb753502cce7c62093aed36ff6d3fa7704f60e6f89b6159e156a8b758bad943d220ae9484221532f7fb440478ec580a',
            // @ts-ignore
            (err, user) => {
            if (err) {
                res.status(401)
                    .json({ ok: false, message: 'The access token is not valid.' });
                return;
            }
    
            // @ts-ignore
            req.user = user;
            next();
        })
    
        // @ts-ignore
        function getBearerToken(req) {
            const authHeader = req.headers['authorization'];
            const token = authHeader && authHeader.split(' ')[1];
            return token;
        }
    }
}