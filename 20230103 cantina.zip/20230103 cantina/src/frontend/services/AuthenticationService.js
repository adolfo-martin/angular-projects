export default class AuthenticationService {

    async retrieveAccessToken(username, password) {
        const url = 'http://127.0.0.1:81/api/authenticate';
        const headers = {
            'Content-Type': 'application/json',
            Accept: 'application/json',
        }
        const body = JSON.stringify({ username, password });
        
        try {
            var response = await fetch(url, { method: 'post', headers, body });
        } catch (error) {
            throw new Error(`Cannot validate user: ${error}`)
        }

        if (response.status === 401) {
            return undefined;
        }

        if (!response.ok) {
            throw new Error(`Cannot validate user: ${response.statusText}`);
        }

        try {
            var data = await response.json();
        } catch (error) {
            throw new Error(`Cannot validate user: ${error}`);
        }

        if (!data.ok) {
            throw new Error(`Cannot validate user: ${data.message}`);
        }

        return data.accessToken;
    }
}