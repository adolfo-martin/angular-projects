export default class CanteenService {
    async retrieveCategories() {
        const token = this._getAccessToken();
        if (!token) {
            throw new Error('There is no token');
        }

        const url = 'http://127.0.0.1/api/categories';

        const headers = new Headers();
        headers.append("Authorization", `Bearer ${token}`);
        headers.append("Content-Type", "application/x-www-form-urlencoded");
    
        try {
            var response = await fetch(url, {
                method: 'get',
                headers: headers,
            })
        } catch (error) {
            throw new Error(`Cannot retrieve categories: ${error}`);
        }
        if (!response.ok) {
            throw new Error(`Cannot retrieve categories: ${response.status} ${response.statusText}`);
        }
    
        try {
            var data = await response.json();
        } catch (error) {
            throw new Error(`Cannot retrieve categories: ${error}`);
        }
        if (!data.ok) {
            throw new Error(`Cannot retrieve categories: ${data.message}`);
        }
    
        return data.categories;
    }

    _getAccessToken() {
        const token = window.sessionStorage.getItem('token');
        return token;
    }
}