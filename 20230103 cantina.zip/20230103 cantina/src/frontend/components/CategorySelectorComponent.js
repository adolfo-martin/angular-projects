import Config from '../Config.js';

export default class CategorySeletorComponent extends HTMLElement {

    static _template = `
        <style>
            .container {
                background-color: var(--lightcolor);
                font-size: 2em;
                text-align: center;
                width: fit-content;
                display: flex;
                flex-direction: column;
                gap: 1em;
            }
            
            .container > div {
                background-color: var(--darkcolor);
                color: var(--lightcolor);
                padding: 1em;
            }
        </style>
        <div id="tDivContainer" class="container"></div>
    `;
        

    constructor() {
        super();
        this._shadowRoot = this.attachShadow({ mode: 'open' });
        this._shadowRoot.innerHTML = CategorySeletorComponent._template;

        this._canteenService = new Config.canteenService();
        this._retrieveAndShowCategories();
    }


    async _retrieveAndShowCategories() {
        const categories = await this._canteenService.retrieveCategories();
        const nContainer = this._shadowRoot.querySelector('#tDivContainer');
        categories.forEach(category => {
            const nDiv = document.createElement('div');
            nContainer.appendChild(nDiv);
            nDiv.setAttribute('data-category', category.uuid);
            nDiv.appendChild(document.createTextNode(category.name));
        })
    }
}

window.customElements.define('category-selector', CategorySeletorComponent);