export default class MessageDialogComponent extends HTMLElement {
    static _template = `
        <style>
            dialog {
                padding: 0;
                border: solid 5px var(--darkcolor);
                display: flex;
                flex-direction: column;
                gap: 0.5em;
            }
            
            header {
                background-color: var(--darkcolor);
                color: var(--lightcolor);
                text-align: center;
                font-size: 1.5em;
                font-weight: bold;
                padding: 0.4em;
            }

            p {
                padding: 1em;
            }

            button {
                border: none;
                font-size: inherit;
                background-color: var(--mediumcolor);
                color: white;
                width: fit-content;
                margin: auto;
                padding: 0.4em 1.5em;
                margin-bottom: 0.5em;
            }

        </style>
        <dialog>
            <header></header>
            <p></p>
            <button>Cerrar</button>
        </dialog>
    `;

    constructor() {
        super();

        this._shadowRoot = this.attachShadow({ mode: 'open' });
        this._shadowRoot.innerHTML = MessageDialogComponent._template;

        const nButton = this._shadowRoot.querySelector('button');
        nButton.addEventListener('click', this.close.bind(this));
    }


    set title(value) {
        this._title = value;
        this._shadowRoot.querySelector('header').textContent = value;
    }


    set message(value) {
        this._message = value;
        this._shadowRoot.querySelector('p').textContent = value;
    }


    set button(value) {
        this._button = value;
        const nButton = this._shadowRoot.querySelector('button');
        nButton.style.display = this._button ? 'block' : 'none';
    }

    showModal() {
        const nDialog = this._shadowRoot.querySelector('dialog');
        nDialog.showModal();
    }


    close() {
        const nDialog = this._shadowRoot.querySelector('dialog');
        nDialog.close();
    }

    // set status(value) {
    //     this._status = value;
    //     const nDialog = this._shadowRoot.querySelector('dialog');
    //     if (value === 'opened') {
    //         nDialog.showModal();
    //     } else {
    //         nDialog.close();
    //     }
    // }

    static get observedAttributes() {
        return [ 'title', 'message', 'status' ];
    }


    attributeChangedCallback(name, oldValue, newValue) {
        this[name] = newValue;
    }
}

window.customElements.define('message-dialog', MessageDialogComponent);