import Config from '../Config.js';

export default class UserAuthenticateComponent extends HTMLElement {
    static _template = `
        <style>
            form {
                display: grid;
                grid-template-columns: auto auto;
                gap: 1em;
                background-color: var(--darkcolor);
                color: var(--lightcolor);
                padding: 1em;
            }

            header {
                grid-column: span 2;
                font-size: 1.5em;
                font-weight: bold;
            }

            label {
                text-align: right;
            }

            input[type="text"], input[type="password"] {
                font-size: inherit;
                outline: none;
            }

            input[type="submit"] {
                grid-column: span 2;
                outline: none;
                background-color: var(--mediumcolor);
                color: var(--lightcolor);
                font-size: inherit;
                padding: 0.4em 1em;
                width: fit-content;
                margin: auto;
            }
        </style>
        <form onsubmit="return false">
            <header>Autenticación de usuarios</header>

            <label>Usuario:</label>
            <input type="text" id="tTxtUsername" required value="sonia.silverado">

            <label>Contraseña:</label>
            <input type="password" id="tTxtPassword" required value="s">

            <input type="submit" id="tButValidateUser" value="Validar usuario">
        </form>
    `;


    constructor() {
        super();

        this._shadowRoot = this.attachShadow({ mode: 'open'});
        this._shadowRoot.innerHTML = UserAuthenticateComponent._template;

        this._authenticationService = new Config.authenticationService();
    }


    connectedCallback() {
        const nButton = this._shadowRoot.querySelector('#tButValidateUser');
        nButton.addEventListener('click', this._validateUserAndPassword.bind(this));
    }


    async _validateUserAndPassword() {
        const eventProcessing = new CustomEvent('authenticationprocessing', {
            detail: { }
        });
        this.dispatchEvent(eventProcessing)

        try {
            const username = this._shadowRoot.querySelector('#tTxtUsername').value;
            const password = this._shadowRoot.querySelector('#tTxtPassword').value;

            const token = await this._authenticationService.retrieveAccessToken(username, password);
            if (!token) {
                const eventFailure = new CustomEvent('authenticationfailure', {
                    detail: { message: 'User or password is wrong' }
                });
                this.dispatchEvent(eventFailure);
                return;
            }
    
            const eventSuccess = new CustomEvent('authenticationsuccess', {
                detail: { token }
            });
            this.dispatchEvent(eventSuccess);
        } catch (error) {
            const eventFailure = new CustomEvent('authenticationfailure', {
                detail: { message: error }
            });
            this.dispatchEvent(eventFailure);
        }
    }
}

window.customElements.define('user-authenticate', UserAuthenticateComponent);