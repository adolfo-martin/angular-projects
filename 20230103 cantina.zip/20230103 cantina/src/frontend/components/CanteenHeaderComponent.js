export default class CanteenHeaderComponent extends HTMLElement {

    static _template = `
        <style>
            header {
                display: flex;
                padding: 0.5em;
            }
            
            .company-name {
                flex-grow: 1;
                font-size: 2.5em;
                font-weight: bold;
                text-align: center;
                text-transform: uppercase;
                
            }

            .start-session, .close-session, .user-name {
                align-self: center;
            }

            .start-session, .close-session {
                background-color: var(--darkcolor);
                color: var(--lightcolor);
                padding: 0.25em 0.4em;
            }
            
            .close-area {
                display: flex;
                flex-direction: column;
            }

            .hidden {
                display: none;
            }
        </style>
        <header>
            <div class="company-name">Cantina Arcas</div>
            <div class="open-area hidden">
                <button class="start-session">Iniciar sesión</button>
            </div>
            <div class="close-area hidden">
                <div class="fullname"></div>
                <button class="close-session">Cerrar sesión</button>
            </div>
        <header>
    `;


    constructor() {
        super();

        this._shadowRoot = this.attachShadow({ mode: 'open' });
        this._shadowRoot.innerHTML = CanteenHeaderComponent._template;
    }

    connectedCallback() {
        this._showOpenCloseButtons();
    }


    _showOpenCloseButtons() {
        const nUserAutenticate = document.querySelector('user-authenticate');
        if (nUserAutenticate) {
            return;
        }

        const token = window.sessionStorage.getItem('token');

        if (token) {
            const nArea = this._shadowRoot.querySelector('.close-area');
            nArea.classList.remove('hidden');
            this._showUserFullname();
            const nButton = this._shadowRoot.querySelector('button.close-session');
            nButton.addEventListener('click', () => {
                const token = window.sessionStorage.removeItem('token');
                window.location = './authenticate_user.htm';
            });
        } else {
            const nArea = this._shadowRoot.querySelector('.open-area');
            nArea.classList.remove('hidden');
            const nButton = this._shadowRoot.querySelector('button.start-session');
            nButton.addEventListener('click', () => window.location = './authenticate_user.htm');
        }
    }


    _showUserFullname() {
        class Authentication {
            static extractFullnameFromToken(token) {
                const decodedToken = Authentication._decodeToken(token);
        
                if (!decodedToken.firstname || !decodedToken.lastname) {
                    throw new Error('Token has not full name.')
                }
        
                return `${decodedToken.firstname} ${decodedToken.lastname}`;
            }
        
            static _decodeToken(token) {
                const parseJwt = token => {
                    try {
                        return JSON.parse(atob(token.split('.')[1]));
                    } catch (error) {
                        throw new Error(`Problem decoding token "${token}": ${error}.`);
                    }
                }
                const tokenDecodificado = parseJwt(token);
                return tokenDecodificado;
            }
            
        
            // static async validarTokenAcceso(token) {
            //     try {
            //         if (!token) {
            //             alert('ERROR. Problema al decodificar el token de acceso.')
            //             window.location = 'https://aulavirtual.iesramonarcas.es/login/index.php'
            //         }
        
            //         var cabeceras = new Headers()
            //         cabeceras.append("Authorization", `Bearer ${token}`)
            //         cabeceras.append("Content-Type", "application/x-www-form-urlencoded")
        
            //         //const respuesta = await fetch(`${URL_BASE}/backend/token-servicio.php`, {
            //         const respuesta = await fetch('../../backend/token-servicio.php', {
            //             method: 'GET',
            //             headers: cabeceras,
            //             redirect: 'follow'
            //         })
            //         const datos = await respuesta.json()
            //         if (datos.estado === 'error') {
            //             alert(`ERROR: ${datos.mensaje}`)
            //             window.location = 'https://aulavirtual.iesramonarcas.es/login/index.php'
            //         }
        
            //         const parseJwt = (token) => {
            //             try {
            //                 return JSON.parse(atob(token.split('.')[1]));
            //             } catch (e) {
            //                 alert('ERROR. Problema al decodificar el token de acceso.')
            //                 window.location = 'https://aulavirtual.iesramonarcas.es/login/index.php'
            //             }
            //         }
            //         const tokenDecodificado = parseJwt(token)
        
            //         if (!tokenDecodificado.usuario || !tokenDecodificado.curso) {
            //             alert('Intento de acceso ilegal.')
            //             window.location = 'https://aulavirtual.iesramonarcas.es/login/index.php'
            //         }
        
            //         return {
            //             usuario: tokenDecodificado.usuario,
            //             curso: tokenDecodificado.curso
            //         }
            //     } catch (e) {
            //         alert(`Problema al recuperar los datos. ${e.message}`)
            //         window.location = 'https://aulavirtual.iesramonarcas.es/login/index.php'
            //     }
            // }
        
            //--------------------------------------------------------------------
            // async solicitarToken(gestor, curso) {
            //     const url = `../../backend/token-servicio.php`;
        
            //     const datosEnvio = new FormData()
            //     datosEnvio.append('usuario', gestor)
            //     datosEnvio.append('curso', curso)
        
            //     const respuesta = await fetch(url, {
            //         method: 'POST',
            //         body: datosEnvio,
            //     });
        
            //     const datos = await respuesta.json();
            //     if (datos.estado === 'error') {
            //         alert(`ERROR (solicitarToken): Problema al generar el token de acceso`);
            //         return null
            //     }
        
            //     return datos.resultado.token
            // }
        }

        const token = window.sessionStorage.getItem('token');
    
        try {
            const fullname = Authentication.extractFullnameFromToken(token);
            const nDiv = this._shadowRoot.querySelector('div.fullname');
            nDiv.textContent = fullname;
        } catch (error) {
            // ErrorDialog.showDialog(
            //     `El usuario no ha sido autenticado. ${error}`,
            //     () => window.location = './index.htm'
            // );
        }
    }
}

window.customElements.define("canteen-header", CanteenHeaderComponent);