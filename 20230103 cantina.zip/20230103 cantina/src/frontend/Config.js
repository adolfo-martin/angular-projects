import AuthenticationService from './services/AuthenticationService.js';
import CanteenService from './services/CanteenService.js';

export default class Config {
    static canteenService = CanteenService;
    static authenticationService = AuthenticationService;
}