document.addEventListener('DOMContentLoaded', setup);

function setup(e) {
    const nAuthentication = document.querySelector('#tAutUserAuthentication');
    nAuthentication.addEventListener('authenticationprocessing', manageAuthenticationProcessing);
    nAuthentication.addEventListener('authenticationsuccess', manageAuthenticationSuccess);
    nAuthentication.addEventListener('authenticationfailure', manageAuthenticationFailure);
}


function manageAuthenticationProcessing(e) {
    const nDialog = document.querySelector('#tDlgMessage');
    nDialog.title = "Información";
    nDialog.message = "Autenticando al usuario. Espere por favor."
    nDialog.button = false;
    nDialog.showModal();
}


function manageAuthenticationSuccess(e) {
    const nDialog = document.querySelector('#tDlgMessage');
    nDialog.close();

    const token = e.detail.token;
    window.sessionStorage.setItem('token', token);
    window.location = './select_category.htm';
}


function manageAuthenticationFailure(e) {
    const nDialog = document.querySelector('#tDlgMessage');
    nDialog.close();

    nDialog.title = "Error";
    nDialog.message = e.detail.message;
    nDialog.button = true;
    nDialog.showModal();
}