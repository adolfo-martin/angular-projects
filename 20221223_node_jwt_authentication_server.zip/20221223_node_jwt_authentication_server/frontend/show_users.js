document.addEventListener('DOMContentLoaded', setup);


async function setup(_) {
    const token = retrieveAndvalidateAccessToken();
    showUserName(token);
    await setupUsersSection(token);
}


function retrieveAndvalidateAccessToken() {
    const token = getAccessToken();
    if (!token) {
        const nDialog = document.querySelector('#tDlgMessage');
        nDialog.message = `El usuario necesita identificarse.`;
        nDialog.show();
        // window.location = './index.htm'
        return;
    }

    return token;
}

function showUserName(token) {
    try {
        const fullname = extractFullnameFromToken(token);
        const nDiv = document.querySelector('#tDivUsername');
        nDiv.textContent = fullname;
    } catch (error) {
        const nDialog = document.querySelector('#tDlgMessage');
        nDialog.message = `El usuario no ha sido autenticado. ${error}`;
        nDialog.show();
    }
}


function extractFullnameFromToken(token) {
    const decodedToken = decodeToken(token);

    if (!decodedToken.firstname || !decodedToken.lastname) {
        throw new Error('Token has not full name.')
    }

    return `${decodedToken.firstname} ${decodedToken.lastname}`;
}

function decodeToken(token) {
    const parseJwt = token => {
        try {
            return JSON.parse(atob(token.split('.')[1]));
        } catch (error) {
            throw new Error(`Problem decoding token "${token}": ${error}.`);
        }
    }
    const tokenDecodificado = parseJwt(token);
    return tokenDecodificado;
}




async function setupUsersSection(token) {
    try {
        const users = await retrieveUsers(token);
        showUsers(users);
    } catch (error) {
        const nDialog = document.querySelector('#tDlgMessage');
        nDialog.message = `No se han podido recuperar los usuarios. ${error}`;
        nDialog.show();
        return;
    }
}


async function retrieveUsers(token) {
    

    const url = 'http://127.0.0.1:80/api/users';
    const headers = new Headers();
    headers.append("Authorization", `Bearer ${token}`);
    headers.append("Content-Type", "application/x-www-form-urlencoded");

    try {
        var response = await fetch(url, {
            method: 'get',
            headers: headers,
            // redirect: 'follow'
        })
    } catch (error) {
        throw new Error(`Cannot retrieve users: ${error}`);
    }
    if (!response.ok) {
        throw new Error(`Cannot retrieve users: ${response.status} ${response.statusText}`);
    }

    try {
        var data = await response.json();
    } catch (error) {
        throw new Error(`Cannot retrieve users: ${error}`);
    }
    if (!data.ok) {
        throw new Error(`Cannot retrieve users: ${data.message}`);
    }

    return data.users;
}


function getAccessToken() {
    const token = window.sessionStorage.getItem('access-token');
    return token;
}


function showUsers(users) {
    const nFather = document.querySelector('#tTabUsers');
    users.forEach(createRow);

    function createRow(user) {
        const nTr = createNode(nFather, 'tr', [['data-username', user.username]])
        const nTd = createNode(nTr, 'td', [['data-username', user.username]], `${user.firstname} ${user.lastname}`)
    }
}


function createNode(nFather, typeNode, attributes, text) {
    const nNewNode = document.createElement(typeNode);
    nFather.appendChild(nNewNode);
    attributes.forEach(attribute => nNewNode.setAttribute(attribute[0], attribute[1]));
    if (text) {
        nNewNode.appendChild(document.createTextNode(text));
    }
    return nNewNode;
}