export default class MyDialogComponent extends HTMLElement {

    _templateText = `
        <style> 
            dialog {
                border: solid 2px blue;
            }
        </style>

        <dialog>
            <header>Aviso</header>
            <p>Mensaje</p>
            <button>X</button>
        </dialog>
    `;


    constructor() {
        super();
        this._message = 'There is not message';
    }
    

    connectedCallback() {
        this._template = document.createElement('template');
        this._template.innerHTML = this._templateText;

        const nTemplate = this._template.content.cloneNode(true);
        this._shadowRoot = this.attachShadow({ mode: 'open'});
        this._shadowRoot.appendChild(nTemplate);

        this._shadowRoot
            .querySelector('dialog>button')
            .addEventListener('click', _ => 
                this._shadowRoot.querySelector('dialog').close()
        )
    }


    set message(message) {
        this._message = message;
        this._shadowRoot.querySelector('dialog>p').textContent = this._message;
    }


    show() {
        this._shadowRoot.querySelector('dialog').showModal();
    }


    close() {
        this._shadowRoot.querySelector('dialog').close();
    }
}


window.customElements.define('my-dialog', MyDialogComponent);