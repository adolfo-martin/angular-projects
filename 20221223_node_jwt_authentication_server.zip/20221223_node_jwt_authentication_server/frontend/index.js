document.addEventListener('DOMContentLoaded', setup);


async function setup(_) {
    setupLoginForm();
}


async function setupLoginForm() {
    setupValidateUserButton();
}


function setupValidateUserButton() {
    document
        .querySelector('#tButValidate')
        .addEventListener('click', async _ => {
            const username = document.querySelector('#tTxtUsername').value;
            const password = document.querySelector('#tTxtPassword').value;

            const nDialog = document.querySelector('#tDlgMessage');
            try {
                nDialog.message = 'Recuperando información. Espere, por favor.'
                nDialog.show();
                const tokens = await validateUserAndRetrieveAccessToken(username, password);
                storeTokens(tokens);
                nDialog.close();
                window.location = './show_users.htm';
            } catch (error) {
                nDialog.close();
                nDialog.message = `No se ha podido validar el usuario. ${error}`;
                nDialog.show();
            }
        });

        function storeTokens(tokens) {
            window.sessionStorage.setItem('access-token', tokens.accessToken);
            window.sessionStorage.setItem('refrest-token', tokens.refreshToken);
        }
}


async function validateUserAndRetrieveAccessToken(username, password) {
    try {
        var response = await fetch('http://127.0.0.1:80/api/login_user', {
            method: 'post',
            headers: {
                'content-type': 'application/json',
                accept: 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
    } catch (error) {
        throw new Error(`Cannot validate user: ${error}`);
    }
    if (!response.ok) {
        throw new Error(`Cannot validate user: ${response.status} ${response.statusText}`);
    }

    try {
        var data = await response.json();
    } catch (error) {
        throw new Error(`Cannot validate user: ${error}`);
    }
    if (!data.ok) {
        throw new Error(`Cannot validate user: ${data.message}`);
    }

    return { accessToken: data.accessToken, refreshToken: data.refreshToken };
}
