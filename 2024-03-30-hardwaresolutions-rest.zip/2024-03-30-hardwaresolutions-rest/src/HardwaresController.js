import express from 'express';


function delay(callback, milliseconds) {
    return (req, res) => setTimeout(() => callback(req, res), milliseconds);
}


export default class HardwaresController {
    #repository;
    #app;
    #router;

    constructor(repository) {
        this.#repository = repository;

        this.#app = express();
        this.#app.use(function (req, res, next) {
            res.header("Access-Control-Allow-Origin", "*");
            res.header("Access-Control-Allow-Methods", "GET");
            res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            res.header('Content-Type', 'application/json');
            next();
        });

        this.#setupRoutes();
    }

    #setupRoutes() {
        this.#router = express.Router();
        this.#router.get('/products', delay(this.getProducts.bind(this), 2000));
        // this.#router.get('/game/:id', getGameById.bind(this));
        // this.#router.get('/genres', getGenres.bind(this));
        // this.#router.get('/genre/:id', getGenreById.bind(this));
        // this.#router.get('/platforms', getPlatforms.bind(this));
        // this.#router.get('/platform/:id', getPlatformById.bind(this));
        // this.#router.get('/publishers', getPublishers.bind(this));
        // this.#router.get('/publisher/:id', getPublisherById.bind(this));
        // this.#router.get('/developers', getDevelopers.bind(this));
        // this.#router.get('/developer/:id', getDeveloperById.bind(this));

        this.#app.use(this.#router);
    }


    async getField(field, callback, req, res) {
        const items = await callback.bind(this.#repository)();
        const result = { ok: true, date: '2024-03-30' };
        result[field] = items;
        // setTimeout(
        //     () => res.status(201).send(result),
        //     2000
        // );
        res.status(201).send(result);
    }


    async getProducts(req, res) {
        await this.getField('products', this.#repository.getProducts, req, res);
    }

    // async function getGenres(req, res) {
    //     await getField('genres', this.#repository.getGenres, req, res);
    // }

    // async function getPlatforms(req, res) {
    //     await getField('platforms', this.#repository.getPlatforms, req, res);
    // }

    // async function getPublishers(req, res) {
    //     await getField('publishers', this.#repository.getPublishers, req, res);
    // }

    // async function getDevelopers(req, res) {
    //     await getField('developers', this.#repository.getDevelopers, req, res);
    // }


    // async function getFieldById(field, callback, req, res) {
    //     const fieldId = req.params.id;
    //     const item = await callback(fieldId);
    //     if (!item) {
    //         const result = { 
    //             ok: false, 
    //             date: '2023-08-31',
    //             error: `Field ${field} with id ${fieldId} not found` 
    //         }
    //         setTimeout(
    //             () => res.status(404).send(result),
    //             250
    //         );
    //         return;
    //     }
    //     const result = { ok: true, date: '2023-08-31' };
    //     result[field] = item;
    //     setTimeout(
    //         () => res.status(201).send(result),
    //         250
    //     );
    // }

    // async function getGameById(req, res) {
    //     await getFieldById('game', this.#repository.getGameById, req, res);
    // }

    // async function getGenreById(req, res) {
    //     await getFieldById('genre', this.#repository.getGenreById, req, res);
    // }

    // async function getPlatformById(req, res) {
    //     await getFieldById('platform', this.#repository.getPlatformById, req, res);
    // }

    // async function getPublisherById(req, res) {
    //     await getFieldById('publisher', this.#repository.getPublisherById, req, res);
    // }

    // async function getDeveloperById(req, res) {
    //     await getFieldById('developer', this.#repository.getDeveloperById, req, res);
    // }

    start(port) {
        this.#app.listen(port, () => console.log(`Listening on port ${port}`));
    }
}