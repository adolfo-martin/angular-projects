import HardwaresController from './HardwaresController.js';
import HardwaresRepository from './HardwaresRepository.js';

const repository = new HardwaresRepository();
const controller = new HardwaresController(repository);
controller.start(3000);