import mysql from 'mysql2';


export default class HardwaresRepository {
    #connection = undefined;

    constructor() {
        this.#connection = mysql.createConnection({
            host: 'hardwaresolutionsdb.gua4axcfehegfcgw.francecentral.azurecontainer.io',
            user: 'root',
            password: 'Hola1234',
            database: 'hardware_solutions',
            port: 3306,
            // insecureAuth : true,
        });
        this.#connection.connect(function (err) {
            if (err) throw err;
            console.log("Connected!");
        });
    }

    async getProducts() {
        return new Promise((resolve, reject) => {
            const query = 'SELECT product_id, product_name FROM products';
    
            this.#connection.query(query, (err, results) => {
                if (err) reject(err);
                resolve(results);
            });
        });
    }

    // async getGameById(id) {
    //     return HardwaresRepository.#hardwares
    //         .find(game => game.id === id);
    // }


    // async getGenreById(id) {
    //     return HardwaresRepository.#genres
    //         .find(genre => genre.id === id);
    // }


    // async getPlatforms() {
    //     return HardwaresRepository.#platforms;
    // }

    // async getPlatformById(id) {
    //     return HardwaresRepository.#platforms
    //         .find(platform => platform.id === id);
    // }

    // static #generateAndUpdatePublishersId() {
    //     const publishers = new Set(HardwaresRepository.#hardwares.map(({ publisher }) => publisher));
    //     HardwaresRepository.#publishers = Array.from(publishers)
    //         .map((publisher, i) => ({ id: crypto.randomUUID(), name: publisher }));

    //     HardwaresRepository.#hardwares
    //         .map(game => {
    //             const uuid = HardwaresRepository.#publishers.find(publisher => publisher.name === game.publisher)['id'];
    //             game.publisher = uuid;
    //             return game;
    //         })
    // }

    // async getPublishers() {
    //     return HardwaresRepository.#publishers;
    // }

    // async getPublisherById(id) {
    //     return HardwaresRepository.#publishers
    //         .find(publisher => publisher.id === id);
    // }

    // static #generateAndUpdateDevelopersId() {
    //     const developers = new Set(HardwaresRepository.#hardwares.map(({ developer }) => developer));
    //     HardwaresRepository.#developers = Array.from(developers)
    //         .map((developer, i) => ({ id: crypto.randomUUID(), name: developer }));

    //     HardwaresRepository.#hardwares
    //         .map(game => {
    //             const uuid = HardwaresRepository.#developers.find(developer => developer.name === game.developer)['id'];
    //             game.developer = uuid;
    //             return game;
    //         })
    // }

    // async getDevelopers() {
    //     return HardwaresRepository.#developers;
    // }

    // async getDeveloperById(id) {
    //     return HardwaresRepository.#developers
    //         .find(developer => developer.id === id);
    // }
}