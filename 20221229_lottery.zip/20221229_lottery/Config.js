import LotteryDrawsRepositoryMock from './repositories/LotteryDrawsRepositoryMock.js';

export default class Config {
    static lotteryDrawsRepository = LotteryDrawsRepositoryMock;
}