import Config from '../Config.js';


document.addEventListener('DOMContentLoaded', setup);


async function setup(e) {
    const repository = new Config.lotteryDrawsRepository();

    const draw = getLotteryDrawFromUrl();

    const view = new WinningTicketsView(repository);
    await view.showWinningTickets(draw);
}


function getLotteryDrawFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const draw = params.get('draw');
    if (!draw) {
        showErrorDialog(error);
        window.location = './index.htm';
    }
    
    return draw;
}

class WinningTicketsView {
    constructor(repository) { 
        this._repository = repository;
    }

    async showWinningTickets(draw) {
        const tickets = await this._repository.retrieveWinningTicketsByDraw(draw);
        const nSection = document.querySelector('#tSctWinningTickets');
        const thisObject = this;

        const tickets2 = await Promise.all(tickets.map(retrieveTicket));
        tickets2.forEach(showTicket);

        async function retrieveTicket(tickedId) {
            const ticket = await thisObject._repository.retrieveWinningTicketById(tickedId);
            return ticket;
        }
 
        function showTicket(ticket) {
            const nTemplate = document.querySelector('#tTmpTicket');            
            const nTicket = nTemplate.content.cloneNode(true).firstElementChild;
            nSection.appendChild(nTicket);

            nTicket.querySelector('#tTxtNumber').value = ticket.number;
            nTicket.querySelector('#tTxtPrize').value = ticket.prize;
        }
    }
        
}
