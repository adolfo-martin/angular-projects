import Config from '../Config.js';


document.addEventListener('DOMContentLoaded', setup);


async function setup(e) {
    const repository = new Config.lotteryDrawsRepository();
    const view = new LotteryDrawsView(repository);
    await view.showLotteryDraws();
}


class LotteryDrawsView {
    constructor(repository) { 
        this._repository = repository;
    }

    async showLotteryDraws() {
        const draws = await this._repository.retrieveLotteryDraws();
        const nTbody = document.querySelector('#tTabLotteryDraw>tbody');
        const thisObject = this;

        draws.forEach(showDraw);

        function showDraw(draw) {
            const nTr = createNode(nTbody, 'tr');
            
            const tTdDate = createNode(nTr, 'td', undefined, draw.date);

            const nTdDenomination = createNode(nTr, 'td', undefined, draw.denomination);

            const nTdDetails = createNode(nTr, 'td', [
                    { field: 'data-id', value: draw.id },
                    { field: 'data-date', value: draw.date },
                    { field: 'data-denomination', value: draw.denomination },
                    { field: 'data-series', value: draw.series },
                    { field: 'data-tickets', value: draw.tickets },
                    { field: 'data-price', value: draw.price },
                ], 
                'Ver detalle');
            nTdDetails.addEventListener('click', thisObject._showDrawDetails);

            const nTdPrizes = createNode(nTr, 'td', [{ field: 'data-draw', value: draw.id }], 'Ir a premios');
            nTdPrizes.addEventListener('click', thisObject._goToPageWinnerTickets);
        }
    }


    _showDrawDetails(e) {
        document.querySelector('input:nth-child(3)').value = e.target.dataset.date;
        document.querySelector('input:nth-child(5)').value = e.target.dataset.denomination;
        document.querySelector('input:nth-child(7)').value = e.target.dataset.series;
        document.querySelector('input:nth-child(9)').value = e.target.dataset.tickets;
        document.querySelector('input:nth-child(11)').value = e.target.dataset.price;

        const nDialog = document.querySelector('#tDlgDrawDetails');
        document.querySelector('button:nth-child(12)').addEventListener('click', e => {
            nDialog.close();
        });
        nDialog.showModal();
    }


    _goToPageWinnerTickets(e) {
        const drawId = e.target.dataset.draw;
        window.location = `./winning-tickets.htm?draw=${drawId}`;
    }
}


function createNode(nAncestor, type, attributes = [], text = '') {
    const nNode = document.createElement(type);
    nAncestor.appendChild(nNode);

    attributes.forEach(attribute => nNode.setAttribute(attribute.field, attribute.value));

    if (text) {
        nNode.appendChild(document.createTextNode(text));
    }

    return nNode;
}