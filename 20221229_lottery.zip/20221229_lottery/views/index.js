import Config from '../Config.js';
import AuthenticationRepository from '../repositories/AuthenticationRepository.js';
import { ErrorDialog } from './utils.js';


document.addEventListener('DOMContentLoaded', setup);


function setup(e) {
    const repository = new Config.lotteryDrawsRepository();
    const view = new IndexView();
    view.setupValidateUserButton();
}


class IndexView {
    setupValidateUserButton() {
        document
            .querySelector('#tButValidateUser')
            .addEventListener('click', this._validateCredentialsUser)
    }

    async _validateCredentialsUser(e) {
        try {
            const username = document.querySelector('#tTxtUsername').value;
            const password = document.querySelector('#tTxtPassword').value;
            
            console.log(username, password);

            const repository = new AuthenticationRepository();
            const authentication = await repository.retrieveUserAuthentication(username, password);
            if (!authentication.ok) {
                new ErrorDialog.showDialog('Usuario o contraseña no es correcto');
                return;
            }

            window.sessionStorage.setItem('token', authentication.token);
            window.location = './choose_origin_airport.htm';
        } catch (error) {
            ErrorDialog.showDialog(`No se ha podido autentificar al usuario: ${error}`);
            return;
        }
    }
}

