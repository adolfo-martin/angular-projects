export default class LotteryDraw {

    constructor(id, date, denomination, series, tickets, price) {
        this.id = id;
        this.date = date;
        this.denomination = denomination;
        this.series = series;
        this.tickets = tickets;
        this.price = price;
    }

    // get id() {
    //     return this._id;
    // }

    // get date() {
    //     return this._date;
    // }

    // get denomination() {
    //     return this._denomination;
    // }

}