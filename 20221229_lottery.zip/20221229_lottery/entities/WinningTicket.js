export default class WinningTicket {

    constructor(id, draw, number, prizeLevel, prize) {
        this.id = id;
        this.draw = draw;
        this.number = number;
        this.prizeLevel = prizeLevel;
        this.prize = prize;
    }
}