import LotteryDraw from '../entities/LotteryDraw.js';
import WinningTicket from '../entities/WinningTicket.js';

export default class LotteryDrawsRepositoryMock {
    static _lotteryDraws = LotteryDrawsRepositoryMock.setupLotteryDraws(); 
    static _winnerTickets = LotteryDrawsRepositoryMock.setupWinnerTickets();

    static setupLotteryDraws() {
        return [
            new LotteryDraw('8735-6931', '2022-12-10', 'Extraordinario "Día de la Constitución"', 10, 100000, 150),
            new LotteryDraw('7366-6912', '2022-12-17', 'Lotería Nacional', 10, 100000, 60),
            new LotteryDraw('3519-3273', '2022-12-22', 'Extraordinario de Navidad', 180, 100000, 200),
            new LotteryDraw('7837-8344', '2023-01-06', 'Extraordinario de "El Niño"', 50, 100000, 200),
        ];
    }


    static setupWinnerTickets() {
        return [
            new WinningTicket('5447-6901', '8735-6931', '80172', 'primer-premio', 1300000),
            new WinningTicket('7515-9802', '8735-6931', '64633', 'primer-premio', 250000),
            new WinningTicket('3265-7403', '7366-6912', '03945', 'primer-premio', 600000),
            new WinningTicket('7483-9204', '7366-6912', '33852', 'primer-premio', 120000),
            new WinningTicket('1287-6905', '3519-3273', '05490', 'primer-premio', 4000000),
            new WinningTicket('7141-7406', '3519-3273', '04074', 'segundo-premio', 125000),
            new WinningTicket('4736-8207', '3519-3273', '45250', 'tercer-premio', 500000),
            new WinningTicket('1482-7608', '3519-3273', '54289', 'cuarto-premio', 200000),
            new WinningTicket('8278-9209', '3519-3273', '25296', 'cuarto-premio', 200000),
            new WinningTicket('1439-8510', '3519-3273', '62391', 'quinto-premio', 60000),
            new WinningTicket('2574-6911', '3519-3273', '43696', 'quinto-premio', 60000),
            new WinningTicket('8571-9612', '3519-3273', '88509', 'quinto-premio', 60000),
            new WinningTicket('3627-7113', '3519-3273', '38454', 'quinto-premio', 60000),
            new WinningTicket('3674-2514', '3519-3273', '24492', 'quinto-premio', 60000),
            new WinningTicket('3165-7915', '3519-3273', '79138', 'quinto-premio', 60000),
            new WinningTicket('3528-7116', '3519-3273', '36142', 'quinto-premio', 60000),
            new WinningTicket('9832-8517', '3519-3273', '87092', 'quinto-premio', 60000),
            new WinningTicket('4178-9518', '7837-8344', '81437', 'primer-premio', 2000000),
            new WinningTicket('5263-7419', '7837-8344', '16185', 'segundo-premio', 750000),
            new WinningTicket('7482-3920', '7837-8344', '33514', 'tercer-premio', 250000),
        ];
    }

    async retrieveLotteryDraws() {
        return LotteryDrawsRepositoryMock._lotteryDraws;
    }


    async retrieveWinningTicketsByDraw(drawId) {
        return LotteryDrawsRepositoryMock._winnerTickets
            .filter(ticket => ticket.draw === drawId)
            .map(ticket => ticket.id);
    }

    async retrieveWinningTicketById(ticketId) {
        return LotteryDrawsRepositoryMock._winnerTickets
            .find(ticket => ticket.id === ticketId);
    }
}