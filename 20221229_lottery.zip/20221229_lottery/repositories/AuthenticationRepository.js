import { SERVER_IP } from "./environment.js";

export default class AuthenticationRepository {

    async retrieveUserAuthentication(username, password) {
        const url = `http://${SERVER_IP}:3002/api/validate_user`;
        
        let response;
        try {
            response = await fetch(url, { 
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                },
                body: JSON.stringify({ username, password })
            });
        } catch (error) {
            throw new Error(`Cannot validate user: ${error}`);
        }
        if (!response.ok) {
            throw new Error(`Cannot validate user: ${response.status} ${response.statusText}`);
        }

        let data;
        try {
            data = await response.json();
        } catch (error) {
            throw new Error(`Cannot validate user: ${error}`);
        }
        if (!data.ok) {
            throw new Error(`Cannot validate user: ${data.message}`);
        }

        return data;
    }
}