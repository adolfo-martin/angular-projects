export default class PageHeader extends HTMLElement {
    static _template = `
        <style>
            :host {
                display: block;
            } 

            header {
                text-align: center;
                text-transform: uppercase;
                padding: 0.5rem;
            }
        </style>
        <header>
            <div class="header__title">
                Lotería Nacional de España
            </div>
            <div class="header__username"></div>
        </header>
    `;

    _username = '';

    connectedCallback() {
        const nTemplate = document.createElement('template');
        nTemplate.innerHTML = PageHeader._template;

        const nClonedTemplate = nTemplate.content.cloneNode(true);
        this._shadowRoot = this.attachShadow({ mode: 'open' });
        this._shadowRoot.appendChild(nClonedTemplate);
    }

    set username(username) {
        this._username = username;
        this._shadowRoot.querySelector('div.header__username').textContent = username;
    }
}


window.customElements.define('page-header', PageHeader);