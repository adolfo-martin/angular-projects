import { createReducer, on } from "@ngrx/store";
import { Product } from "../entities/product";
import { addProduct, clearCart, removeProduct } from "./cart.actions";

export const initialCartItems: Product[] = []

const _clearCart = (_: any) => []

const _addProduct = (items: Product[], product: Product) => {
    const itemsClone: Product[] = JSON.parse(JSON.stringify(items))
    itemsClone.push(product)
    return itemsClone
}

const _removeProduct = (items: Product[], product: Product) => {
    const itemsClone: Product[] = JSON.parse(JSON.stringify(items))
    const foundItem = itemsClone.find(item => item.uuid === product.uuid)
    if (foundItem) {
        itemsClone.splice(itemsClone.indexOf(foundItem), 1)
    }
    return itemsClone
}

export const cartReducer = createReducer(
    initialCartItems,
    on(clearCart, _clearCart),
    on(addProduct, _addProduct),
    on(removeProduct, _removeProduct),
)