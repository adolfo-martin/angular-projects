import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { finalize, Observable } from 'rxjs';
import { ProductsService } from '../../../services/products.service';
import { Product } from '../../entities/product';

@Component({
  selector: 'products-table',
  templateUrl: './products-table.component.html',
  styleUrls: ['./products-table.component.css']
})
export class ProductsTableComponent implements OnInit {

  products$!: Observable<Product[]>

  @Output('productsLoaded') private _productsLoadedEmitter = new EventEmitter()

  @Output('productChanged') private _productChangedEmitter = new EventEmitter<string>()

  constructor(private _productsService: ProductsService) { }

  ngOnInit(): void {
    this.products$ = this._productsService.retrieveProducts().pipe(
      finalize(() => this.emitProductsLoaded())
    )
  }

  emitProductChanged(e: Event) {
    // @ts-ignore
    const productUuid: string = e.currentTarget.value
    this._productChangedEmitter.emit(productUuid)
  }

  emitProductsLoaded() {
    this._productsLoadedEmitter.emit()
  }
}
