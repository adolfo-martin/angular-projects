import { Component, effect, inject } from '@angular/core';
import { ApplicationStatusService } from '../../services/application-status-service';
import { DummyRestService } from '../../services/dummy-rest-service';

@Component({
  selector: 'button-login',
  imports: [],
  templateUrl: './button-login.html',
  styleUrl: './button-login.css',
})
export class ButtonLogin {
  protected readonly statusService = inject(ApplicationStatusService);
  private readonly restService = inject(DummyRestService);

  constructor() {
    effect(() => {
      // @ts-ignore
      console.log(this.statusService.token());
    });
  }

  openSessionHandler($event: PointerEvent) {
    this.restService.validateUser$('emilys', 'emilyspass').subscribe(token => this.statusService.openSession(token));
  }
}
