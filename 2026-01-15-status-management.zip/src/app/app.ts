import { Component, signal } from '@angular/core';
import { ButtonLogin } from "./components/button-login/button-login";

@Component({
  selector: 'app-root',
  imports: [ButtonLogin],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
}
