import { computed, effect, Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ApplicationStatusService {

  private readonly token = signal<string | null>(null);

  public isLogged = computed(() => this.token() ? true : false);

  public fullname = computed(() => {
    if (this.isLogged()) {
      // @ts-ignore
      const { firstName, lastName } = this.decodeToken(this.token());
      return `${firstName} ${lastName}`;
    } else {
      return '';
    }
  });

  // constructor() {
  //   effect(() => {
  //     console.log(this.token());
  //   });
  // }

  public closeSession() {
    this.token.set(null);
  }

  public openSession(token: string) {
    this.token.set(token);
  }


  private decodeToken(token: string) {
    const parseJwt = (token: string) => {
      try {
        return JSON.parse(atob(token.split('.')[1]));
      } catch (error) {
        // @ts-ignore
        throw new Error(`Problem decoding token "${token}": ${error.message}.`);
      }
    }
    const tokenDecodificado = parseJwt(token);
    return tokenDecodificado;
  }

}
