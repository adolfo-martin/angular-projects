import { Injectable } from '@angular/core';
import { BehaviorSubject, map } from 'rxjs';

export enum SessionStatus {
  OPEN = 'OPEN',
  CLOSE = 'CLOSE', 
}

export type UserT = {
  firstname: string,
  lastname: string,
}

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {  
  private _user$ = new BehaviorSubject<UserT | null>(null);
  public user$ = this._user$.asObservable();

  public sessionStatus$ = this.user$.pipe(
    map(user => user !== null ? SessionStatus.OPEN : SessionStatus.CLOSE)
  );

  constructor() { }

  public validateUser(username: string, password: string): void {
    if (username === 'sonia.silverado' && password === 'Hola1234') {
      this._user$.next({firstname: 'Sonia', lastname: 'Silverado'});
    }
  }

  public closeSession() {
    this._user$.next(null);
  }
}