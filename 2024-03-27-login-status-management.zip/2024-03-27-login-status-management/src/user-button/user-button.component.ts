import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AuthenticationService, SessionStatus, UserT } from '../authentication.service';

@Component({
  selector: 'user-button',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-button.component.html',
  styleUrl: './user-button.component.css'
})
export class UserButtonComponent {
  sessionStatusTypes = SessionStatus;
  sessionStatus$ = this._authService.sessionStatus$;
  user$ = this._authService.user$;

  public constructor(private _authService: AuthenticationService) { }

  openSession(e: any) {
    this._authService.validateUser('sonia.silverado', 'Hola1234');
  }

  closeSession(e: any) {
    this._authService.closeSession();
  }
}
