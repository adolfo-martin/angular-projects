import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { UserButtonComponent } from '../user-button/user-button.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, UserButtonComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = '2024-03-27-ngrx-test';
}
